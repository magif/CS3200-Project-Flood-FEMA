create definer = root@localhost trigger patient_after_update_pregnant
    after update
    on patient
    for each row
BEGIN

    -- Patient became pregnant
    IF (NEW.is_pregnant = 1 AND OLD.is_pregnant = 0) THEN
        -- Add pre-natal recommenation
        INSERT INTO recommendation (patient_id, message)
        VALUES (NEW.patient_id, 'Take pre-natal vitamins');

        -- Delete any prescriptions that shouldn't be taken if pregnant
        DELETE p
        FROM prescription p
                 JOIN medication m USING (medication_id)
        WHERE p.patient_id = NEW.patient_id
          AND m.take_if_pregnant = 0;


        -- Patient is no longer pregnant
    ELSEIF (NEW.is_pregnant = 0 AND OLD.is_pregnant = 1) THEN
        -- Remove pre-natal recommendation
        DELETE
        FROM recommendation
        WHERE patient_id = NEW.patient_id
          AND message = 'Take pre-natal vitamins';
    END IF;


END;

