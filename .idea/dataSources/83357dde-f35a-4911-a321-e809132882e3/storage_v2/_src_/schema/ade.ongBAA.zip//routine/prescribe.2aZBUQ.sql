create
    definer = root@localhost procedure prescribe(IN patient_name_param varchar(255), IN doctor_name_param varchar(255),
                                                 IN medication_name_param varchar(255), IN ppd_param int)
begin
    -- variable declarations
    declare patient_id_var int;
    declare age_var float;
    declare is_pregnant_var boolean;
    declare weight_var int;
    declare doctor_id_var int;
    declare medication_id_var int;
    declare take_under_12_var boolean;
    declare take_if_pregnant_var boolean;
    declare mg_per_pill_var double; -- ignore
    declare max_mg_per_10kg_var double; -- ignore

    declare message varchar(255); -- The error message
    declare ddi_medication varchar(255);
    -- The name of a medication involved in a drug-drug interaction

    -- select relevant values into variables 
    -- Get patient details (age calculated from DOB)
    SELECT patient_id,
           TIMESTAMPDIFF(YEAR, dob, CURDATE()),
           is_pregnant
    INTO patient_id_var,
        age_var,
        is_pregnant_var
    FROM patient
    WHERE patient_name = patient_name_param
    LIMIT 1;

    -- Get doctor details
    SELECT doctor_id
    INTO doctor_id_var
    FROM doctor
    WHERE doctor_name = doctor_name_param
    LIMIT 1;

    -- Get medication details
    SELECT medication_id,
           take_under_12,
           take_if_pregnant
    INTO medication_id_var,
        take_under_12_var,
        take_if_pregnant_var
    FROM medication
    WHERE medication_name = medication_name_param
    LIMIT 1;


    -- check age of patient
    -- I did one for you! This shows how to throw an exception and set an error message.
    if (age_var < 12
        and take_under_12_var = false) then
        select concat(medication_name_param, ' cannot be prescribed to children under 12.') into message;
        signal sqlstate 'HY000' set message_text = message;
    end if;

    -- check if medication ok for pregnant women (or the patient is not pregnant)
    if (is_pregnant_var = true
        and take_if_pregnant_var = false) then
        select concat(medication_name_param, ' cannot be prescribed to pregnant women.') into message;
        signal sqlstate 'HY000' set message_text = message;
    end if;

    -- Check for drug-drug interactions involving the prescribed medication and
    -- any medications already prescribed to patient
    -- If there is a drug interaction, report the name of the interacting medication

    -- Resets ddi_medication to ensure it's null before checking
    SET ddi_medication = NULL;

    SELECT m.medication_name
    INTO ddi_medication
    FROM prescription p
             JOIN interaction i ON p.medication_id = i.medication_2
             JOIN medication m USING (medication_id)
    WHERE p.patient_id = patient_id_var
      AND i.medication_1 = medication_id_var
    LIMIT 1;

    if (ddi_medication is not null) then
        select concat(medication_name_param, ' interacts with ', ddi_medication, ' currently prescribed to ',
                      patient_name_param, '.')
        into message;
        signal sqlstate 'HY000' set message_text = message;
    end if;

    -- No exceptions thrown, so insert the prescription record
    INSERT INTO prescription (medication_id, patient_id, doctor_id, ppd)
    VALUES (medication_id_var, patient_id_var, doctor_id_var, ppd_param);

    -- No exceptions thrown, so insert the prescription record

end;

